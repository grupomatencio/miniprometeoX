<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <div class="col-8 offset-2 isla-list p-4 mt-5">
            <div class="ttl text-center mb-4">
                <h1>Crear máquina</h1>
            </div>
            <form action="<?php echo e(route('machines.store')); ?>" method="POST" autocomplete="off">
                <?php echo csrf_field(); ?>

                <!-- Delegation ID (hidden) -->
                <input type="hidden" name="delegation_id" value="1">

                <!-- Nombre -->
                <div class="form-floating mb-3">
                    <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="floatingName" placeholder="Nombre máquina" value="<?php echo e(old('name')); ?>">
                    <label for="floatingName">Nombre máquina</label>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"> <?php echo e($message); ?> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Alias -->
                <div class="form-floating mb-3">
                    <input type="text" name="alias" class="form-control <?php $__errorArgs = ['alias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="floatingAlias" placeholder="Alias máquina" value="<?php echo e(old('alias')); ?>">
                    <label for="floatingAlias">Alias máquina</label>
                    <?php $__errorArgs = ['alias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"> <?php echo e($message); ?> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Modelo -->
                <div class="col-5 d-flex justify-content-between">
                    <div>
                        <p>Tipo modelo: </p>
                    </div>
                    <?php $__currentLoopData = ['A', 'B', 'C', 'X']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input class="form-check-input <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="radio"
                                name="model" id="model<?php echo e($modelType); ?>" value="<?php echo e($modelType); ?>"
                                <?php echo e(old('model') == $modelType ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="model<?php echo e($modelType); ?>"><?php echo e($modelType); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback d-block pb-4"> <?php echo e($message); ?> </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <!-- Código -->
                <div class="form-floating mb-3">
                    <input type="text" name="codigo" class="form-control <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="floatingCodigo" placeholder="Código" value="<?php echo e(old('codigo')); ?>">
                    <label for="floatingCodigo">Código</label>
                    <?php $__errorArgs = ['codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"> <?php echo e($message); ?> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Serie -->
                <div class="form-floating mb-3">
                    <input type="text" name="serie" class="form-control <?php $__errorArgs = ['serie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="floatingSerie" placeholder="Serie" value="<?php echo e(old('serie')); ?>">
                    <label for="floatingSerie">Serie</label>
                    <?php $__errorArgs = ['serie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"> <?php echo e($message); ?> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Número -->
                <div class="form-floating mb-3">
                    <input type="text" name="numero" class="form-control <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="floatingNumero" placeholder="Número" value="<?php echo e(old('numero')); ?>">
                    <label for="floatingNumero">Número</label>
                    <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"> <?php echo e($message); ?> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Botón de Enviar -->
                <div class="form-group mt-3">
                    <button type="submit" class="btn btn-primary">Crear máquina</button>
                    <button type="reset" class="btn btn-danger">Limpiar</button>
                </div>
            </form>

            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    const radios = document.querySelectorAll('input[name="local"]');
                    const resumen = document.getElementById('resumenLocales');

                    function updateResumen() {
                        const selectedRadio = document.querySelector('input[name="local"]:checked');
                        if (selectedRadio) {
                            const label = document.querySelector(`label[for="${selectedRadio.id}"]`);
                            resumen.textContent = `Local seleccionado: ${label.textContent}`;
                        } else {
                            resumen.textContent = 'Local seleccionado: Taller';
                        }
                    }

                    // Escuchar cambios en los radios
                    radios.forEach(radio => {
                        radio.addEventListener('change', updateResumen);
                    });

                    // Actualizar resumen al cargar la página (en caso de que haya un valor preseleccionado)
                    updateResumen();
                });
            </script>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Desktop/miniprometeoXX/miniprometeoXX/resources/views/machines/create.blade.php ENDPATH**/ ?>