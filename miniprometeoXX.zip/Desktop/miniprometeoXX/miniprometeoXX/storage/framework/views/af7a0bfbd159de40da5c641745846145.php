<?php $__env->startSection('titulo', 'Delegations'); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="container d-none d-md-block">
        <div class="row">
            <div class="col-12 text-center d-flex justify-content-center mt-3 mb-3" id="headerAll">
                <div class="w-50 ttl">
                    <h1>Máquinas delegación Benidorm</h1>
                </div>
            </div>

            <div class="col-10 offset-1 mt-5">
                <div class="row">
                    <div class="col-10 offset-1 isla-list">
                        <div class="p-4 pb-0">
                            <div class="row p-2">
                                <div class="col-12">
                                    <a class="btn btn-primary w-100 btn-ttl">Máquinas</a>
                                </div>
                            </div>
                            <form action="<?php echo e(route('machines.search')); ?>" method="GET" class="mb-4"
                                autocomplete="off">
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control"
                                        placeholder="Buscar máquinas...">
                                    <div class="input-group-append">
                                        <button class="btn btn-warning" type="submit">Buscar</button>
                                    </div>
                                </div>
                            </form>
                            <table class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th scope="col">Alias</th>
                                        <th scope="col">Identificador</th>
                                        <th scope="col">Auxiliar</th>
                                        <th scope="col"><a class="btn btn-primary w-100 btn-ttl"
                                            href="<?php echo e(route('machines.create')); ?>">+</a></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="user-row">
                                            <form action="<?php echo e(route('machines.update', $machine->id)); ?>" method="POST" autocomplete="off">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                    <td>
                                                        <input type="text" class="form-control w-50 <?php $__errorArgs = ['alias.' .$machine->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            name = "alias[<?php echo e($machine -> id); ?>]"
                                                            id="<?php echo e($machine -> id); ?>"
                                                            value = "<?php echo e($machine->alias); ?>"
                                                            disabled>
                                                        <?php $__errorArgs = ['alias.' .$machine->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback text-start"> <?php echo e($message); ?> </div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </td>
                                                    <td><?php echo e($machine->identificador); ?></td>
                                                    <td>
                                                        <input type="text" class="form-control w-50 <?php $__errorArgs = ['auxiliar.' .$machine->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            id="<?php echo e($machine -> id); ?>"
                                                            name ="auxiliar[<?php echo e($machine->id); ?>]"
                                                            value = "<?php echo e($machine->auxiliar); ?>"
                                                            disabled>
                                                        <?php $__errorArgs = ['auxiliar.' .$machine->id];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="invalid-feedback text-start"> <?php echo e($message); ?> </div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex">
                                                            <button type="button" class="btn btn-primary w-100 btn-in edit" id="<?php echo e($machine -> id); ?>">Editar</button>
                                                            <button type="submit" class="btn btn-success w-100 btn-in d-none guardar" id="<?php echo e($machine -> id); ?>">Guardar</button>
                                                            <button type="button" class="btn btn-primary w-100 btn-in ms-2 d-none volver" id="<?php echo e($machine -> id); ?>">Volver</button>
                                                            <a class="btn btn-danger w-100 btn-inf ms-2 eliminar" id="<?php echo e($machine -> id); ?>" data-bs-toggle="modal"
                                                                data-bs-target="#modalAccionesLocal<?php echo e($machine->id); ?>">Eliminar</a>
                                                        </div>
                                                    </td>

                                            </form>
                                        </tr>

                                        <!--MODAL ACCIONES-->
                                        <div class="modal fade" id="modalAccionesLocal<?php echo e($machine->id); ?>"
                                            data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                                            aria-labelledby="modalAcciones" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="modalAccionesLabel">Acciones para
                                                            la
                                                            máquina <?php echo e($machine->name); ?></h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="text-center">
                                                            <a class="btn btn-danger" data-bs-toggle="modal"
                                                                data-bs-target="#eliminarModal<?php echo e($machine->id); ?>">
                                                                Eliminar
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!--Modal eliminar-->
                                        <div class="modal fade" id="eliminarModal<?php echo e($machine->id); ?>"
                                            data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                                            aria-labelledby="eliminarModal<?php echo e($machine->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">!Eliminar
                                                            <?php echo e($machine->name); ?>!</h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        ¿Estas seguro que quieres eliminar la máquina <?php echo e($machine->name); ?>?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <form action="<?php echo e(route('machines.destroy', $machine->id)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>

                                                            <button type="submit" class="btn btn-danger">Eliminar</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="col-4 offset-8 pb-1">
                                <a class="btn btn-danger w-100" data-bs-toggle="modal"
                                    data-bs-target="#modalPdf">Exportar <i class="bi bi-filetype-pdf"></i></a>

                                <!-- MODAL EXPORTAR PDF -->
                                <div class="modal fade" id="modalPdf" data-bs-backdrop="static" data-bs-keyboard="false"
                                    tabindex="-1" aria-labelledby="modalPdfLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="modalPdfLabel">¿Qué máquinas quieres
                                                    exportar?</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="text-center">
                                                    <a class="btn btn-warning w-100 mb-2"
                                                        href="#}">Máquinas
                                                        Salones</a>
                                                    <a class="btn btn-warning w-100"
                                                        href="#">Máquinas
                                                        Bares</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>


                            <div class="col-4 offset-8 pb-4">
                                <a class="btn btn-success w-100" href="<?php echo e(route('import.index')); ?>"> Importar <i class="bi bi-box-arrow-in-right"></i>
                                </a>

                                <div class="d-flex justify-content-center mt-4">
                                    <?php if(session ('errorConfiguracion')): ?>
                                        <div class="text-danger fw-semibold text-center"><?php echo e(session ('errorConfiguracion')); ?> </div>
                                    <?php endif; ?>
                                </div>
                            </div>




                            </div>



                            <div class="d-flex justify-content-center mt-4">
                               pagination
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container d-block d-md-none text-center pt-5">
        <div class="ttl d-flex align-items-center p-2">
            <div>
                <a href="#" class="titleLink">
                    <i style="font-size: 30pt" class="bi bi-arrow-bar-left"></i>
                </a>
            </div>
            <div>
                <h1>Máquinas delegación Benidorm</h1>
            </div>
        </div>

        <div class="mt-5 p-3 isla-list">
            <?php if(count($machines) != 0): ?>
                <div class="row p-2 mb-4">
                    <div class="col-12">
                        <a class="btn btn-primary w-100 btn-ttl">Máquinas</a>
                    </div>
                </div>
                <form action="#" method="GET" class="mb-4"
                    autocomplete="off">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Buscar máquinas...">
                        <div class="input-group-append">
                            <button class="btn btn-warning" type="submit">Buscar</button>
                        </div>
                    </div>
                </form>
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Identificador</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $machines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $machine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="user-row">
                                <td><?php echo e($machine->name); ?></td>
                                <td><?php echo e($machine->identificador); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="col-4 offset-8 pb-4">
                    <a class="btn btn-primary w-100 btn-inf" data-bs-toggle="modal" data-bs-target="#modalPdfTlf"><i class="bi bi-filetype-pdf"></i> Exportar</a>

                    <!-- MODAL EXPORTAR PDF -->
                    <div class="modal fade" id="modalPdfTlf" data-bs-backdrop="static" data-bs-keyboard="false"
                        tabindex="-1" aria-labelledby="modalPdfTlfLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="modalPdfLabel">¿Qué máquinas quieres
                                        exportar?</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="text-center">
                                        <a class="btn btn-warning w-100 mb-2"
                                            href="#">Máquinas
                                            Salones</a>
                                        <a class="btn btn-warning w-100"
                                            href="#">Máquinas
                                            Bares</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="d-flex justify-content-center mt-4">
                      Pagination <!--  { $machines->links('vendor.pagination.bootstrap-5') }} -->
                </div>
            <?php else: ?>
                <p>No existen máquinas!</p>
            <?php endif; ?>
        </div>
    </div>
<script>

        const editButtons = document.querySelectorAll('.edit');
        const guardarButtons = document.querySelectorAll('.guardar');
        const volverButtons = document.querySelectorAll('.volver');
        const inputs = document.querySelectorAll('.form-control');
        const eliminarButtons = document.querySelectorAll('.eliminar');

        editButtons.forEach(button => {
            button.addEventListener('click', function() {
                const buttonId = Number (event.target.id);

                editButtons.forEach(but => {
                    if (Number(but.id) == buttonId) {
                        but.classList.add('d-none');
                    } else {
                        but.classList.remove('d-none');
                    }
                })
                inputs.forEach(input => {
                    if (Number(input.id) == buttonId) {
                        input.removeAttribute('disabled');
                    } else {
                        input.setAttribute('disabled', 'true');
                    }
                })
                guardarButtons.forEach(guardar => {
                    if (Number(guardar.id) == buttonId) {
                        guardar.classList.remove('d-none');
                    } else {
                        guardar.classList.add('d-none');
                    }
                })

                volverButtons.forEach(volver => {
                    if (Number(volver.id) == buttonId) {
                        volver.classList.remove('d-none');
                    } else {
                        volver.classList.add('d-none');
                    }
                })

                eliminarButtons.forEach(eliminar => {
                    console.log(eliminarButtons);
                    if (Number(eliminar.id) == buttonId) {
                        eliminar.classList.add('d-none');
                    } else {
                        eliminar.classList.remove('d-none');
                    }
                })

            })
        })

        volverButtons.forEach(button => {
            button.addEventListener('click', function() {

                editButtons.forEach(but => {
                    but.classList.remove('d-none');
                })
                inputs.forEach(input => {
                    input.setAttribute('disabled', 'true');
                })
                guardarButtons.forEach(guardar => {
                    guardar.classList.add('d-none');
                })

                volverButtons.forEach(volver => {
                    volver.classList.add('d-none');
                })

                eliminarButtons.forEach(eliminar => {
                    eliminar.classList.remove('d-none');
                })
            })
        })


</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alumno/Desktop/miniprometeoXX/miniprometeoXX/resources/views/machines/index.blade.php ENDPATH**/ ?>